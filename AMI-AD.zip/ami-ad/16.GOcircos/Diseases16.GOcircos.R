######Video source: https://ke.biowolf.cn
######������ѧ��: https://www.biowolf.cn/
######΢�Ź��ںţ�biowolf_cn
######�������䣺biowolf@foxmail.com
######����΢��: 18520221056

#install.packages("circlize")
#install.packages("RColorBrewer")


#���ð�
library(circlize)
library(RColorBrewer)

input="GO.txt"      #�����ļ�
outpdf="GO.circos.pdf"     #����Ľ���ļ�
setwd("D:\\biowolf\\Diseases\\16.GOcircos")     #���ù���Ŀ¼

#��ȡ�����ļ�
data=read.table(input, header=T, sep="\t", check.names=F)
data=data[order(data$pvalue),]     #����pvalue�����ݽ�������
data=head(data, n=8)      #չʾ������������ǰ�˸�GO
pvalue=round(-log(data$pvalue,10),2)
#��ȡչʾ������б�
genelist=unlist(strsplit(data$geneID,"/"))
genetable=table(genelist)

#����ͼ�ε���ɫ
GO_col = colorRampPalette(brewer.pal(9, "Paired"))(nrow(data))
genes_col = rainbow(length(names(genetable)),s=0.7,v=0.7)
pvalue_col_fun <- colorRamp2(
	breaks = c(min(pvalue), mean(pvalue), max(pvalue)), 
	colors = c("#FFFFCC", "#FF9966", "#FF0000")
)

#��ȡ����͹��ܵĶ�Ӧ��ϵ
genedict = list()
for(i in names(genetable)) genedict[[i]] = 0
GOdict = list()
for(i in data$Description) GOdict[[i]] = 0
# link  gene--GO
gene_GO_list = list()
n = 0
for(i in 1:nrow(data)){
  genei = strsplit(data$geneID[i],"/")[[1]] # multi
  GOi = data$Description[i]
  for(j in 1:length(genei)){
    n = n+1
    genej = genei[j] # single
    gene_GO_list[[n]] = data.frame(gene=genej,GO=data$Description[i],start=genedict[[genej]],
                                        end=genedict[[genej]]+1,start2 = GOdict[[GOi]],end2=GOdict[[GOi]]+1,
                                        pvalue=pvalue[i])
    genedict[[genej]] = genedict[[genej]]+1
    GOdict[[GOi]] = GOdict[[GOi]]+1
  }
}
#gene \t GO \t start \t end \t pvalue
gene_GO_data = as.data.frame(do.call('rbind',gene_GO_list))
gene_GO_data$linkcol = GO_col[as.numeric(as.factor(gene_GO_data$GO))]
#right GO
data3 = data.frame(id=data$Description,start = 0, end = data$Count)
# left top
data1 = data.frame(id=names(genetable),start=0,end = as.numeric(genetable))
# main chrom
df = as.data.frame(rbind(data3,data1))

#���������Եı��
get_sig = function(p){
  ifelse(p> -log(0.001,10),"***",ifelse(p> -log(0.01,10),'**','*'))
}

bed3 = data.frame(data3,yt=0,yb=1,col=GO_col[as.numeric(as.factor(data3$id))],p=0,text='')
bed1 = data.frame(data1,yt=0.5,yb=1,col=genes_col[as.numeric(as.factor(data1$id))],p=0,text='')
bed2 = data.frame(id=gene_GO_data$gene,start=gene_GO_data$start,
                  end=gene_GO_data$end,yt=0,yb=0.5,
                  col=pvalue_col_fun(gene_GO_data$pvalue),p=gene_GO_data$pvalue,
                  text=get_sig(gene_GO_data$pvalue))

bed = as.data.frame(rbind(bed1,bed2,bed3))

#����ͼ��
pdf(file=outpdf, width=12, height=7)
layout(mat=matrix(c(1,1,1,0,2,3),nc=2),width=c(6.5,3.5),height=c(2,2,7))
#��ʼ��ͼ��
circos.par(track.margin=c(0.01,0.01), start.degree=90)
circos.genomicInitialize(df,plotType="none")

#չʾ���������
circos.trackPlotRegion(ylim = c(0, 1), panel.fun = function(x, y) {
  sector.index = get.cell.meta.data("sector.index")
  xlim = get.cell.meta.data("xlim")
  ylim = get.cell.meta.data("ylim")
  if(!any(data3$id%in%sector.index)){
    circos.text(mean(xlim), mean(ylim), sector.index, cex = 1, facing = "bending.inside", niceFacing = TRUE)
  }
}, track.height = 0.08, bg.border = NA,bg.col = NA)
#չʾͼ�ε�ԲȦ
circos.genomicTrack(bed, ylim = c(0, 1),track.height = 0.15,bg.border=NA,
                    panel.fun = function(region, value, ...) {
                      i = getI(...)
                      circos.genomicRect(region, value, ytop = value[,1], ybottom = value[,2], col = value[,3],
                                         border = "black", ...)
                      for(j in 1:nrow(value)){
                        if(value[j,4]!=0){
                          circos.genomicText(region[j,], value[j,], y = 0.25, labels = value[j,5], adj=0.5,cex=1,...)
                        }
                      }
                    })

#չʾ���ܺͻ������ϵ
for(i in 1:nrow(gene_GO_data)){
  genei = gene_GO_data$gene[i]
  GOi = gene_GO_data$GO[i]
  circos.link(genei, c(gene_GO_data$start[i], gene_GO_data$end[i]), 
              GOi, c(gene_GO_data$start2[i], gene_GO_data$end2[i]), 
              col = gene_GO_data$linkcol[i], border = "black")
}
circos.clear()

#�����ұ�pvalue��ͼ��
par(mar=c(3,0,3,10))
barplot(rep(1,100),col=pvalue_col_fun(seq(min(pvalue),max(pvalue),length=100)),
        space=0,border=NA,xaxt="n",yaxt="n",main="-log10(pvalue)")
axis(1,c(1,50,100),c(min(pvalue),mean(pvalue),max(pvalue)),tick=F)

#����GO���Ƶ�ͼ��
par(mar=c(0,0,0,0))
plot(1,type="n",axes=F,xlab="",ylab="")
legend("left",legend=bed3$id,col=bed3$col,pch=15,pt.cex=3,cex=1.2,bty="n",title="Gene Ontology")
dev.off()


######Video source: https://ke.biowolf.cn
######������ѧ��: https://www.biowolf.cn/
######΢�Ź��ںţ�biowolf_cn
######�������䣺biowolf@foxmail.com
######����΢��: 18520221056

